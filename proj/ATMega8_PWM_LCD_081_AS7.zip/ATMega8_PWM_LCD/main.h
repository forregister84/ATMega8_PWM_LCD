#ifndef MAIN_H_
#define MAIN_H_

// #define F_CPU 1000000UL  //1 MHz
#define F_CPU 16000000UL  //16 MHz

#define FREQ_DEF 160000 // Частота по умолчанию

#define FREQ_MAX (F_CPU/4)
//#define FREQ_MAX 100000UL //100 кГц
//#define FREQ_MAX 65535UL //0xFFFF

#define PWM_DEF 5000    // ШИМ по умолчанию = 50 %
#define PWM_MIN 100  //1%
#define PWM_MAX 9900 //99%

//Задержка записи после нажатия на кнопку (чтобы не записывать слишком часто)
#define SAVE_DELAY 20 //BTN_DELAY*SAVE_DELAY= 100*20=2000 мс

// Кнопки:
//PB0 - MODE (было PC5)
//PC4 - FREQ-
//PC3 - FREQ+
//PC1 - DUTY-
//PC0 - DUTY+

#define BTN_DELAY 100 // Задержка 100 мс на антидребезг, для симуляции сделать 30...100 мс
// #define BTN_DELAY 30
#define Button_Mode  BitIsClear(PINB,0) //Кнопка Mode.
#define Button_FreqM BitIsClear(PINC,4) //Freq-
#define Button_FreqP BitIsClear(PINC,3) //Freq+
#define Button_DutyM BitIsClear(PINC,1) //Duty(PWM)-
#define Button_DutyP BitIsClear(PINC,0) //Duty(PWM)+

//------------------------------------------------------------------------------
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/wdt.h>  // Библиотека для работы со сторожевым таймером
#include <avr/eeprom.h>
#include <util/delay.h>
//#include <stdio.h> //printf

#include "bits_macros.h"
#include "lcd_lib_uni1.h" // Alphanumeric LCD Module functions

//------------------------------------------------------------------------------
// Timer2 output compare interrupt service routine
//ISR (TIMER2_COMP_vect);

// Timer1 Overflow interrupt routine
//ISR (TIMER1_OVF_vect);
//------------------------------------------------------------------------------
// преобразует 16-bit 4-х разрядное число, записывает его в буфер индикатора
// value - число для преобразования, comma = 0...3 - позиция точки на индикаторе(слева направо) 0...AMOUNT_NUM-1,
//                                   comma >=    5 -  без точки  (AMOUNT_NUM+1)
// (comma = количество символов до точки)
void Uint_to_str (unsigned int value, unsigned char comma);

//Преобразование периода в частоту
uint32_t conv_period_freq (void);

//Преобразование ton в PWM Duty (коэффициент заполнения)
uint16_t conv_ton_PWM (void);

//Расчет регистров 16-bit таймера 1 на основе частоты и коэффициента заполнения ШИМ
void T1_reg_calc (void);

//Проверка состояния кнопок
uint8_t button_scan(void);

//------------------------------------------------------------------------------
#endif /* MAIN_H_ */