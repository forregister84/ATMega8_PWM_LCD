
//Библиотека LCD, режим 4 бит
//RS,E, D4-D7 должны быть подключены к одному порту
//в произвольном порядке
//Вывод RW индикатора подключен к земле и к контроллеру не подключается

//макросы для работы с битами
#ifndef BITS_MACROS_
#define ClearBit(reg, bit)       reg &= (~(1<<(bit)))
#define SetBit(reg, bit)         reg |= (1<<(bit))	
#define BitIsSet(reg, bit)       ((reg & (1<<bit)) != 0)
#endif//BITS_MACROS_

unsigned char __swap_nibbles(unsigned char data)
{
asm volatile("swap %0" : "=r" (data) : "0" (data));
return data;
}  


void _set_half(unsigned char data)
{
  PORT_LCD &=~((1<<D7)|(1<<D6)|(1<<D5)|(1<<D4));//Очищаем биты
  if (BitIsSet(data,4)) SetBit(PORT_LCD,D4); 
  if (BitIsSet(data,5)) SetBit(PORT_LCD,D5); 
  if (BitIsSet(data,6)) SetBit(PORT_LCD,D6);   
  if (BitIsSet(data,7)) SetBit(PORT_LCD,D7); 
}  

inline static void LCD_Wait(void)
{
  _delay_us(40);
}

void LCD_WriteComInit(unsigned char data)
{
  LCD_Wait();
  ClearBit(PORT_LCD, RS);	//установка RS в 0 - команды

  _set_half(data);		//вывод старшей тетрады 

  SetBit(PORT_LCD, EN);	        //установка E в 1
  _delay_us(2);
  ClearBit(PORT_LCD, EN);	//установка E в 0 - записывающий фронт
}

inline static void LCD_CommonFunc(unsigned char data)
{
   _set_half(data);		//вывод старшей тетрады 
  
  SetBit(PORT_LCD, EN);	//установка E в 1         
  _delay_us(2);
  ClearBit(PORT_LCD, EN);//установка E в 0 - записывающий фронт	 	

  data = __swap_nibbles(data);
  _set_half(data); 
  //_set_half(data<<4);		//вывод младшей тетрады 
  
  SetBit(PORT_LCD, EN);	//установка E в 1        
  _delay_us(2);
  ClearBit(PORT_LCD, EN);//установка E в 0 - записывающий фронт	 
}

//функция записи команды 
void LCD_WriteCom(unsigned char data)
{
  LCD_Wait();
  ClearBit(PORT_LCD, RS);	//установка RS в 0 - команды
  LCD_CommonFunc(data);
}

//функция записи данных
void LCD_SendChar(unsigned char data)
{
  LCD_Wait();
  SetBit(PORT_LCD, RS);	        //установка RS в 1 - данные
  LCD_CommonFunc(data);
}

//функция инициализации
void LCD_Init(void)
{    
  DDRX_LCD |=(1<<D7)|(1<<D6)|(1<<D5)|(1<<D4)|(1<<RS)|(1<<EN);
  PORT_LCD |=(1<<D7)|(1<<D6)|(1<<D5)|(1<<D4)|(1<<RS)|(1<<EN); 
  _delay_ms(40);
  
#ifdef HD44780  
  LCD_WriteComInit(0x30); 
  _delay_ms(10);
  LCD_WriteComInit(0x30);
  _delay_ms(1);
  LCD_WriteComInit(0x30);
#endif
  
  LCD_WriteComInit(0x20); //4-ми разрядная шина
  LCD_WriteCom(0x28); //4-ми разрядная шина, 2 - строки

  LCD_WriteCom(0x08);
  LCD_WriteCom(0x0c);  //0b00001111 - дисплей вкл, курсор и мерцание выключены
  LCD_WriteCom(0x01);  //0b00000001 - очистка дисплея
  _delay_ms(2);
  LCD_WriteCom(0x06);  //0b00000110 - курсор движется вправо, сдвига нет
}

/*
//функция вывода строки из флэш памяти
void LCD_SendStringFlash(char *str PROGMEM)
{
  unsigned char data;			
  while (*str)
  {
    data = *str++;
    LCD_SendChar(data);
  }
}
*/

//функция вывода строки из ОЗУ
void LCD_SendString(char *str)
{
  unsigned char data;
  while (*str)
  {
    data = *str++;
    LCD_SendChar(data);
  }
}

//очистка ЖКИ
void LCD_Clear(void)
{
  LCD_WriteCom(0x01);
  _delay_ms(2);
}
